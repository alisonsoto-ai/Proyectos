-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 22-08-2026 a las 03:02:23
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `lifeline`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ll_alertas`
--

CREATE TABLE `ll_alertas` (
  `id_alerta` int(10) UNSIGNED NOT NULL,
  `tipo_sangre` varchar(10) NOT NULL,
  `id_sede` int(10) NOT NULL,
  `mensaje` text NOT NULL,
  `fecha_envio` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ll_alertas`
--

INSERT INTO `ll_alertas` (`id_alerta`, `tipo_sangre`, `id_sede`, `mensaje`, `fecha_envio`) VALUES
(9, 'A+', 2, 'prueba numero 7', '2025-10-27 00:05:33'),
(10, 'A+', 2, 'URGENTE DONAR', '2026-07-28 14:11:01'),
(11, 'A+', 2, 'URGENTE DONAR', '2026-07-28 14:11:02'),
(12, 'A+', 2, 'URGENTE DONAR', '2026-07-28 14:11:03'),
(13, 'A+', 2, 'URGENTE DONAR', '2026-07-28 14:11:03'),
(14, 'A+', 2, 'URGENTE DONAR', '2026-07-28 14:11:04'),
(19, 'A+', 1, 'se necesita urgente este tipo de sangre\r\n', '2026-08-03 02:37:50'),
(20, 'A+', 1, 'URGENTE SE NECESITA DONANTES DE TIPO A', '2026-08-07 18:15:53'),
(21, 'A+', 2, 'URGENTE SE NECEISTA DONANTES DE SANGRE A', '2026-08-07 18:28:44'),
(22, 'A+', 1, 'URGENTE SE NECESITA DONANTES DE A', '2026-08-07 18:46:16'),
(23, 'A+', 2, 'urgente se necesita el tipo  de sangre A+', '2026-08-10 21:53:17'),
(24, 'A+', 1, 'SE NECESITA A*', '2026-08-10 22:37:56'),
(25, 'A+', 1, 'URGENTE SE NECESITA SANGRE TIPO A+', '2026-08-11 05:14:57'),
(26, 'A+', 1, 's enecesita angre', '2026-08-21 19:44:28'),
(27, 'A+', 1, 'se ', '2026-08-21 19:48:02'),
(28, 'A+', 1, 'sangre', '2026-08-21 19:52:03'),
(29, 'A+', 1, 'seangre', '2026-08-21 23:10:57'),
(30, 'A+', 1, 'sangre', '2026-08-22 00:58:57');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ll_registro`
--

CREATE TABLE `ll_registro` (
  `id_registro` int(20) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `apellido` varchar(20) NOT NULL,
  `tipo_sangre` varchar(15) NOT NULL,
  `dni` int(15) NOT NULL,
  `fecha` date NOT NULL,
  `correo` varchar(30) NOT NULL,
  `telefono` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ll_registro`
--

INSERT INTO `ll_registro` (`id_registro`, `nombre`, `apellido`, `tipo_sangre`, `dni`, `fecha`, `correo`, `telefono`) VALUES
(27, 'Daniel', 'Sosa', 'A+', 48432438, '2025-10-22', 'baezsosad@gmail.com', 1162159428),
(28, 'agustin', 'baez', 'Lo desconoce', 48432438, '2025-10-27', 'baezsosad@gmail.com', 1162159428),
(29, 'Alison', 'Soto', 'A+', 48463440, '2026-07-28', 'alisonmelanysotoo@gmail.com', 133675322),
(30, 'Alison', 'Soto', 'A+', 48463440, '2026-08-10', 'alisonmelanysotoo@gmail.com', 1128372757),
(31, 'Alison', 'Soto', 'A+', 48463440, '2026-08-10', 'alisonmelanysotoo@gmail.com', 1128372757),
(32, 'Alison', 'Soto', 'A+', 48463440, '2026-08-10', 'alisonmelanysotoo@gmail.com', 1128372757),
(33, 'Abril', 'Benites', 'A+', 48717076, '2026-08-21', 'abriltqw@gmail.com', 1163568580);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ll_rol`
--

CREATE TABLE `ll_rol` (
  `id_rol` int(30) NOT NULL,
  `rol_us` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ll_rol`
--

INSERT INTO `ll_rol` (`id_rol`, `rol_us`) VALUES
(2, 'administrador\r\n'),
(1, 'donante');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ll_sede`
--

CREATE TABLE `ll_sede` (
  `id_sede` int(30) NOT NULL,
  `nombre_sede` varchar(50) NOT NULL,
  `Localidad_sede` varchar(30) NOT NULL,
  `telefono_sede` int(11) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ll_sede`
--

INSERT INTO `ll_sede` (`id_sede`, `nombre_sede`, `Localidad_sede`, `telefono_sede`, `password`) VALUES
(1, 'Centro Regional de Bella Vista', 'Bella Vista', 1146669898, 'admin1234'),
(2, 'Sede Moron', 'Moron', 1146669898, 'admin1234'),
(3, 'Centro Regional Ciudad de Buenos Aires', 'CABA', 1145541411, 'admin1234');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ll_turnos`
--

CREATE TABLE `ll_turnos` (
  `id_turno` int(11) NOT NULL,
  `id_registro` int(11) NOT NULL,
  `id_sede` int(11) NOT NULL,
  `tipo_donacion` varchar(15) NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `estado` varchar(20) NOT NULL,
  `agradecimiento_enviado` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ll_turnos`
--

INSERT INTO `ll_turnos` (`id_turno`, `id_registro`, `id_sede`, `tipo_donacion`, `fecha`, `hora`, `estado`, `agradecimiento_enviado`) VALUES
(4, 27, 2, 'Sangre', '2025-11-01', '23:52:00', 'Completado', 1),
(5, 27, 1, 'Sangre', '2025-11-08', '08:40:00', 'Completado', 1),
(6, 29, 2, 'Plaquetas', '2026-11-11', '17:11:00', 'pendiente', 0),
(7, 27, 1, 'Plaquetas', '4444-04-04', '22:30:00', 'pendiente', 0),
(8, 32, 1, 'Plaquetas', '2026-08-11', '22:15:00', 'Completado', 0),
(9, 32, 1, 'Sangre', '2026-11-11', '22:17:00', 'pendiente', 0),
(10, 32, 2, 'Sangre', '2026-10-13', '22:30:00', 'pendiente', 0),
(11, 32, 1, 'Sangre', '2026-08-12', '22:15:00', 'pendiente', 0),
(12, 32, 1, 'Sangre', '2026-08-12', '22:15:00', 'pendiente', 0),
(13, 33, 1, 'Sangre', '2026-08-22', '14:00:00', 'pendiente', 0),
(14, 33, 1, 'Sangre', '2026-08-27', '13:30:00', 'pendiente', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ll_usuario`
--

CREATE TABLE `ll_usuario` (
  `id_usuario` int(100) NOT NULL,
  `usuario` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ll_usuario`
--

INSERT INTO `ll_usuario` (`id_usuario`, `usuario`, `password`) VALUES
(32, 'alison', '1234'),
(33, 'abril', '123');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `ll_alertas`
--
ALTER TABLE `ll_alertas`
  ADD PRIMARY KEY (`id_alerta`),
  ADD KEY `id_sede` (`id_sede`);

--
-- Indices de la tabla `ll_registro`
--
ALTER TABLE `ll_registro`
  ADD PRIMARY KEY (`id_registro`),
  ADD UNIQUE KEY `id_registro` (`id_registro`);

--
-- Indices de la tabla `ll_rol`
--
ALTER TABLE `ll_rol`
  ADD PRIMARY KEY (`id_rol`),
  ADD UNIQUE KEY `id_rol` (`id_rol`,`rol_us`),
  ADD UNIQUE KEY `rol_us` (`rol_us`),
  ADD UNIQUE KEY `rol_us_2` (`rol_us`);

--
-- Indices de la tabla `ll_sede`
--
ALTER TABLE `ll_sede`
  ADD PRIMARY KEY (`id_sede`);

--
-- Indices de la tabla `ll_turnos`
--
ALTER TABLE `ll_turnos`
  ADD PRIMARY KEY (`id_turno`),
  ADD KEY `id_registro` (`id_registro`),
  ADD KEY `id_sede` (`id_sede`);

--
-- Indices de la tabla `ll_usuario`
--
ALTER TABLE `ll_usuario`
  ADD PRIMARY KEY (`id_usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `ll_alertas`
--
ALTER TABLE `ll_alertas`
  MODIFY `id_alerta` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT de la tabla `ll_registro`
--
ALTER TABLE `ll_registro`
  MODIFY `id_registro` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT de la tabla `ll_rol`
--
ALTER TABLE `ll_rol`
  MODIFY `id_rol` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `ll_sede`
--
ALTER TABLE `ll_sede`
  MODIFY `id_sede` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `ll_turnos`
--
ALTER TABLE `ll_turnos`
  MODIFY `id_turno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de la tabla `ll_usuario`
--
ALTER TABLE `ll_usuario`
  MODIFY `id_usuario` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `ll_alertas`
--
ALTER TABLE `ll_alertas`
  ADD CONSTRAINT `ll_alertas_ibfk_1` FOREIGN KEY (`id_sede`) REFERENCES `ll_sede` (`id_sede`) ON DELETE CASCADE;

--
-- Filtros para la tabla `ll_turnos`
--
ALTER TABLE `ll_turnos`
  ADD CONSTRAINT `ll_turnos_ibfk_1` FOREIGN KEY (`id_registro`) REFERENCES `ll_registro` (`id_registro`),
  ADD CONSTRAINT `ll_turnos_ibfk_2` FOREIGN KEY (`id_sede`) REFERENCES `ll_sede` (`id_sede`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

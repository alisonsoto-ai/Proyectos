<?php
include("db.php");

// Obtener el ID del turno a eliminar
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id > 0) {
    if (isset($_GET['confirmar']) && $_GET['confirmar'] == 'si') {
        $sql = "DELETE FROM ll_turnos WHERE id_turno=$id";

        if ($conexion->query($sql) === TRUE) {
            echo '<div class="alert alert-success">Turno eliminado correctamente.</div>';
        } else {
            echo '<div class="alert alert-danger">Error al eliminar el turno: ' . $conexion->error . '</div>';
        }

        header("Location: detalle_donante.php");
        exit;

    } else {
        ?>
        <!DOCTYPE html>
        <html lang="es">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Life Line - Eliminar Turno</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
            <link rel="stylesheet" href="style.css">
        </head>
        <body>
            <div class="container mt-5">
                <h2>Panel de Administración - Eliminar Turno</h2>
                <div class="alert alert-warning">
                    ¿Estás seguro de que deseas eliminar este turno? Esta acción no se puede deshacer.
                </div>

                <form method="get" action="eliminar_turno.php">
                    <input type="hidden" name="id" value="<?php echo $id; ?>">
                    <button type="submit" class="btn btn-danger" name="confirmar" value="si">Sí, eliminar</button>
                    <a href="detalle_donante.php" class="btn btn-secondary">No, cancelar</a>
                </form>
            </div>
        </body>
        </html>
        <?php
    }
} else {
    echo '<div class="alert alert-danger">ID de turno no válido.</div>';
    header("Location: detalle_donante.php");
    exit;
}

$conexion->close();
?>
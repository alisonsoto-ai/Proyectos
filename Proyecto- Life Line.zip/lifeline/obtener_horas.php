<?php
session_start();
include("db.php");

if (!isset($_SESSION['id_usuario'])) {
    http_response_code(403);
    echo json_encode([]);
    exit;
}

$id_sede = isset($_GET['id_sede']) ? (int)$_GET['id_sede'] : 0;
$fecha   = isset($_GET['fecha'])   ? $conexion->real_escape_string($_GET['fecha']) : '';

if (!$id_sede || !$fecha) {
    echo json_encode([]);
    exit;
}

// 1. Obtener las horas que YA están reservadas para esa sede y fecha
$horas_ocupadas = [];

$query = "SELECT DATE_FORMAT(hora, '%H:%i') AS hora 
          FROM ll_turnos 
          WHERE id_sede = '$id_sede' 
          AND fecha = '$fecha' 
          AND estado != 'cancelado'";

$resultado = $conexion->query($query);

while ($row = $resultado->fetch_assoc()) {
    $horas_ocupadas[] = $row['hora'];
}

// 2. Definir el horario de atención total (ejemplo: 08:00 a 16:00 cada 30 minutos)
$hora_inicio = strtotime("08:00");
$hora_fin    = strtotime("16:00");
$intervalo   = 30 * 60; // 30 minutos en segundos

$horas_disponibles = [];
$fecha_actual = date('Y-m-d');
$hora_actual  = date('H:i');

for ($i = $hora_inicio; $i <= $hora_fin; $i += $intervalo) {
    $hora_slot = date('H:i', $i);
    
    // Si la fecha elegida es HOY, descartar las horas que ya pasaron
    if ($fecha == $fecha_actual && $hora_slot <= $hora_actual) {
        continue;
    }

    // Si la hora NO está en el arreglo de horas ocupadas, se agrega a las disponibles
    if (!in_array($hora_slot, $horas_ocupadas)) {
        $horas_disponibles[] = $hora_slot;
    }
}

// 3. Devolver la lista en formato JSON
header('Content-Type: application/json');
echo json_encode($horas_disponibles);

$conexion->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Life Line - Turnos</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Panel de Administración - Turnos</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Donante</th>
                    <th>Sede</th>
                    <th>Fecha</th>
                    <th>Hora</th>
                    <th>Estado</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include("db.php");

                // Consulta para obtener turnos con información de donantes y sedes
                $sql = $conexion->query("
                    SELECT t.id_turno, r.nombre, r.apellido, s.nombre_sede, t.fecha, t.hora, t.estado
                    FROM ll_turnos t
                    JOIN ll_registro r ON t.id_registro = r.id_registro
                    JOIN ll_sede s ON t.id_sede = s.id_sede
                ");

                while ($datos = $sql->fetch_object()) {
                ?>
                    <tr>
                        <td><?php echo $datos->id_turno; ?></td>
                        <td><?php echo htmlspecialchars($datos->nombre . ' ' . $datos->apellido); ?></td>
                        <td><?php echo htmlspecialchars($datos->nombre_sede); ?></td>
                        <td><?php echo htmlspecialchars($datos->fecha); ?></td>
                        <td><?php echo htmlspecialchars($datos->hora); ?></td>
                        <td><?php echo htmlspecialchars($datos->estado); ?></td>
                        <td>
                            <a href="editar_turno.php?id=<?php echo $datos->id_turno; ?>" class="btn btn-primary btn-sm">Editar</a>
                            <a href="eliminar_turno.php?id=<?php echo $datos->id_turno; ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de eliminar este turno?');">Eliminar</a>
                        </td>
                    </tr>
                <?php
                }

                if ($sql->num_rows == 0) {
                    echo "<tr><td colspan='7' class='text-center'>No hay turnos registrados.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
<?php
session_start();
include("db.php");

// Verificamos si el usuario o el admin está logueado
if (isset($_SESSION['id_usuario'])) {
    $id_usuario = $_SESSION['id_usuario'];
} else {
    // Si no hay sesión activa, redirigir al login
    header("Location: login.html");
    exit;
}

$id_registro = $_SESSION['id_usuario'];

// Verificar si el formulario se envió
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_sede = $conexion->real_escape_string($_POST['id_sede']);
    $fecha = $conexion->real_escape_string($_POST['fecha']);
    $hora = $conexion->real_escape_string($_POST['hora']);
    $estado = "pendiente"; // Estado inicial para usuarios
    $tipo_donacion = $conexion->real_escape_string($_POST['tipo_donacion']);

    // Validación básica
    $fecha_actual = date('Y-m-d');
    $hora_actual = date('H:i');

    if (empty($id_sede) || empty($fecha) || empty($hora)) {
        $mensaje = '<div class="alert alert-danger">Todos los campos son obligatorios.</div>';
    } elseif ($fecha < $fecha_actual || ($fecha == $fecha_actual && $hora < $hora_actual)) {
        $mensaje = '<div class="alert alert-danger">No puedes seleccionar una fecha u hora pasada.</div>';
    } else {

        $sql = "INSERT INTO ll_turnos 
                (id_registro, id_sede, tipo_donacion, fecha, hora, estado) 
                VALUES ('$id_registro', '$id_sede', '$tipo_donacion', '$fecha', '$hora', '$estado')";

        if ($conexion->query($sql) === TRUE) {
            $mensaje = '<div class="alert alert-success">Turno registrado correctamente.</div>';
        } else {
            $mensaje = '<div class="alert alert-danger">Error al registrar el turno: ' . $conexion->error . '</div>';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Life Line - Sacar Turno</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style2.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>
<body class="fondo-turno">
    <header class="encabezado">

    <h2 class="logo">LIFE LINE</h2>

    <nav class="menu">

        <a href="inicio-usuario2.php">Inicio</a>


        
        <div class="submenu">

            <a href="sobre-donar2.html">
                Sobre donar 
                <i class="fa-solid fa-chevron-down"></i>
            </a>


            <div class="submenu-contenido">

                <a href="sangre2.html">
                    <i class="fa-solid fa-droplet"></i>
                    Sangre
                </a>

                <a href="plaquetas2.html">
                    <i class="fa-solid fa-hand-holding-medical"></i>
                    Plaquetas
                </a>

                <a href="requisitos2.html">
                    <i class="fa-solid fa-droplet"></i>
                    Requisitos
                </a>

            </div>

        </div>


        <a href="centros2.html">Centros</a>


        
        <div class="submenu">

            <a href="#">
                Información
                <i class="fa-solid fa-chevron-down"></i>
            </a>


            <div class="submenu-contenido">

                <a href="historias.html">
                    <i class="fa-solid fa-book-open"></i>
                    Historias
                </a>


                <a href="preguntas.html">
                    <i class="fa-solid fa-circle-question"></i>
                    Preguntas y Mitos
                </a>
                <a href="colectas.html">
                    <i class="fa-solid fa-house"></i>
                    Colectas
                </a>

            </div>

        </div>


        <a href="sacar_turno.php">Reservar Turnos</a>

        <a href="sobre-nosotros2.html">Nosotros</a>


    </nav>


    
    <a href="perfil_donante.html" class="icono-usuario">

        <i class="fa-solid fa-user"></i>

    </a>


</header>
    <div class="container mt-5">
        <h2>Sacar Turno</h2>
        <?php if (isset($mensaje)) echo $mensaje; ?>

        <form method="post">
            <input type="hidden" name="id_registro" value="<?php echo htmlspecialchars($id_registro); ?>">

            <div class="mb-3">
                <label for="id_sede" class="form-label">Sede</label>
                <select class="form-control" id="id_sede" name="id_sede" required>
                    <option value="">-- Selecciona una sede --</option>
                    <?php
                    $sql_sedes = $conexion->query("SELECT id_sede, nombre_sede FROM ll_sede");
                    while ($sede = $sql_sedes->fetch_object()) {
                        echo "<option value='$sede->id_sede'>$sede->nombre_sede</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="mb-3">
                <label for="tipo_donacion" class="form-label">Tipo de Donación:</label>
                <select class="form-control" name="tipo_donacion" required>
                    <option value="">-- Selecciona --</option>
                    <option value="Sangre">Sangre</option>
                    <option value="Plaquetas">Plaquetas</option>
                </select>
            </div>

            <div class="mb-3">
                <label for="fecha" class="form-label">Fecha</label>
                <input type="date" class="form-control" id="fecha" name="fecha" min="<?php echo date('Y-m-d'); ?>" required>
            </div>

            <div class="mb-3">
                <label for="hora" class="form-label">Hora disponible</label>
                <select class="form-control" id="hora" name="hora" required disabled>
                    <option value="">-- Primero selecciona Sede y Fecha --</option>
                </select>
            </div>

            <button type="submit" class="btn btn-primary">Sacar Turno</button>
            <a href="inicio-usuario2.php" class="btn btn-secondary">Volver</a>
        </form>
    </div>

    <!-- Script de JavaScript para consultar las horas en tiempo real -->
    <script>
    document.addEventListener("DOMContentLoaded", function() {
        const selectSede = document.getElementById("id_sede");
        const inputFecha = document.getElementById("fecha");
        const selectHora = document.getElementById("hora");

        function cargarHorasDisponibles() {
            const idSede = selectSede.value;
            const fecha = inputFecha.value;

            // Limpiar el select de horas mientras carga
            selectHora.innerHTML = '<option value="">-- Cargando horarios... --</option>';

            if (idSede && fecha) {
                selectHora.disabled = true;

                // Consultar al script PHP secundario
                fetch(`obtener_horas.php?id_sede=${idSede}&fecha=${fecha}`)
                    .then(response => response.json())
                    .then(horas => {
                        selectHora.innerHTML = '<option value="">-- Selecciona una hora --</option>';

                        if (horas.length === 0) {
                            selectHora.innerHTML = '<option value="">No hay turnos disponibles para esta fecha</option>';
                        } else {
                            horas.forEach(hora => {
                                const option = document.createElement("option");
                                option.value = hora;
                                option.textContent = hora;
                                selectHora.appendChild(option);
                            });
                            selectHora.disabled = false;
                        }
                    })
                    .catch(error => {
                        console.error("Error al cargar las horas:", error);
                        selectHora.innerHTML = '<option value="">Error al obtener horarios</option>';
                    });
            } else {
                selectHora.innerHTML = '<option value="">-- Primero selecciona Sede y Fecha --</option>';
                selectHora.disabled = true;
            }
        }

        
        selectSede.addEventListener("change", cargarHorasDisponibles);
        inputFecha.addEventListener("change", cargarHorasDisponibles);
    });
    </script>
    
    <footer class="pie-pagina">
    <div class="contenido-footer">

        <div class="marca-footer">
            <img src="imagenes/logoasd.png" alt="LifeLine" class="logo-footer">
            <p>
                LifeLine conecta donantes con centros de salud para facilitar la
                donación de sangre de forma rápida, segura y accesible.
            </p>
            <div class="redes-footer">
                <a href="#"><i class="fa-brands fa-instagram"></i></a>
                <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
            </div>
        </div>

        <div class="columna-footer">
            <h4>Navegación</h4>
            <a href="#">Inicio</a>
            <a href="#">Requisitos</a>
            <a href="#">Sobre donar</a>
            <a href="#">Centros</a>
            <a href="#">Contacto</a>
        </div>

        <div class="columna-footer">
            <h4>Información</h4>
            <a href="#">Preguntas frecuentes</a>
            <a href="#">Cómo donar</a>
        </div>

        <div class="columna-footer">
            <h4>Contacto</h4>
            <a href="#">lifeline.org@.com</a>
            <a href="#">+54 11 2345-6789</a>
            <a href="#">San Miguel, Buenos Aires</a>
        </div>

    </div>

    <div class="barra-footer">
        <span>© 2026 LifeLine. Todos los derechos reservados.</span>
    </div>
</footer>

</body>
</html>

<?php
$conexion->close();
?>
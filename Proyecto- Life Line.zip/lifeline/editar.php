<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Sede</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <?php
    include("db.php");

    // Obtener el ID de la sede a editar
    $id = isset($_GET['id']) ? intval($_GET['id']) : 0;

    // Procesar el formulario de edición
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $nombre_sede = $conexion->real_escape_string($_POST['nombre_sede']);
        $localidad_sede = $conexion->real_escape_string($_POST['localidad_sede']);
        $telefono_sede = $conexion->real_escape_string($_POST['telefono_sede']);
        $password = $conexion->real_escape_string($_POST['password']);

        $sql = "UPDATE ll_sede SET nombre_sede='$nombre_sede', Localidad_sede='$localidad_sede', telefono_sede='$telefono_sede', password='$password' WHERE id_sede=$id";

        if ($conexion->query($sql) === TRUE) {
            echo '<div class="alert alert-success">Sede modificada correctamente.</div>';
        } else {
            echo '<div class="alert alert-danger">Error al modificar la sede: ' . $conexion->error . '</div>';
        }
    }

    // Obtener los datos actuales de la sede
    $sql = "SELECT * FROM ll_sede WHERE id_sede=$id";
    $resultado = $conexion->query($sql);
    $sede = $resultado->fetch_assoc();
    ?>

    <div class="container mt-5">
        <h2>Panel de Administración - Editar Sede</h2>
        <form method="post">
            <div class="mb-3">
                <label for="nombre_sede" class="form-label">Nombre de la Sede</label>
                <input type="text" class="form-control" id="nombre_sede" name="nombre_sede" value="<?php echo htmlspecialchars($sede['nombre_sede']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="localidad_sede" class="form-label">Localidad</label>
                <input type="text" class="form-control" id="localidad_sede" name="localidad_sede" value="<?php echo htmlspecialchars($sede['Localidad_sede']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="telefono_sede" class="form-label">Teléfono</label>
                <input type="text" class="form-control" id="telefono_sede" name="telefono_sede" value="<?php echo htmlspecialchars($sede['telefono_sede']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Contraseña</label>
                <input type="text" class="form-control" id="password" name="password" value="<?php echo htmlspecialchars($sede['password']); ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Guardar Cambios</button>
            <a href="admin.php" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>
</body>

</html>
<?php
// Incluir la conexión a la base de datos
include 'db.php';

// Procesar el formulario si se envía
if (isset($_POST['btn_registro'])) {
    // Capturar los datos del formulario
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $tipo_sangre = $_POST['tipo_sangre'];
    $dni = $_POST['dni'];
    $fecha = date('Y-m-d'); // Fecha actual
    $correo = $_POST['correo'];
    $password = $_POST['password']; // Contraseña sin hashear (como pediste)
    $telefono = $_POST['telefono'];
    $usuario = $_POST['usuario'];

    // --- PRIMERA CONSULTA: Insertar en la tabla 'll_registro' ---
    $sql1 = "INSERT INTO ll_registro (nombre, apellido, tipo_sangre, dni, fecha, correo, telefono)
             VALUES ('$nombre', '$apellido', '$tipo_sangre', '$dni', '$fecha', '$correo', '$telefono')";

    $resultado1 = mysqli_query($conexion, $sql1);

    if ($resultado1) {
        // Obtener el id autoincremental generado en 'll_registro'
        $id_registro = mysqli_insert_id($conexion);

        // --- SEGUNDA CONSULTA: Insertar en la tabla 'll_usuario' usando el mismo id ---
        $sql2 = "INSERT INTO ll_usuario (id_usuario, usuario, password)
                 VALUES ('$id_registro', '$usuario', '$password')";

        $resultado2 = mysqli_query($conexion, $sql2);

        if ($resultado2) {
            // Redirigir si todo sale bien
            header("Location: login.html");
            exit;
        } else {
            die("Error al agregar usuario: " . mysqli_error($conexion));
        }
    } else {
        die("Error al agregar registro: " . mysqli_error($conexion));
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Life Line - Registro</title>
    <!-- Bootstrap CSS (opcional, para estilos) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <header class="header">
        <div class="logo">
            <img src="imagenes/logo.png" alt="Life Line Logo">
        </div>
        <nav>
            <ul class="nav-links">
                <li><a href="index.php">Inicio</a></li>
                <li><a href="Requisitos.php">Requisitos</a></li>
                <!-- Menú desplegable DONAR -->
                <li class="dropdown">
                    <a href=# class="dropbtn">Donar</a>
                    <ul class="dropdown-content">
                        <li><a href="sangre.html">Sangre</a></li>
                        <li><a href="plaquetas.html">Plaquetas</a></li>
                    </ul>
                </li>
                <li><a href="Lifeline.php">Sobre Life Line</a></li>
                <li><a href="index.php#contacto">Contacto</a></li>

            </ul>
        </nav>
        <a href="login.html" class="btn-registrarse">👤 Iniciar Sesión </a>
    </header>
    <div class="container mt-5" style="max-width: 400px;">
        <h2>Agregar Nueva Persona</h2>
        <form action="" method="POST">
            <div class="mb-3">
                <label for="nombre" class="form-label">Nombre:</label>
                <input type="text" class="form-control" name="nombre" required>
            </div>
            <div class="mb-3">
                <label for="apellido" class="form-label">Apellido:</label>
                <input type="text" class="form-control" name="apellido" required>
            </div>
            <div class="mb-3">
                <label for="tipo_sangre" class="form-label">Tipo de Sangre:</label>
                <select class="form-control" name="tipo_sangre" required>
                    <option value="">-- Selecciona --</option>
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                    <option value="RH-">RH-</option>
                    <option value="Lo desconoce">Lo desconozco</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="localidad" class="form-label">DNI:</label>
                <input type="text" class="form-control" name="dni" required>
            </div>
            <div class="mb-3">
                <label for="fecha" class="form-label">Fecha Actual:</label>
                <input type="text" class="form-control" value="<?php echo date('Y-m-d'); ?>" readonly>
            </div>
            <div class="mb-3">
                <label for="telefono" class="form-label">Teléfono:</label>
                <input type="tel" class="form-control" name="telefono" required>
            </div>
            <div class="mb-3">
                <label for="correo" class="form-label">Correo:</label>
                <input type="email" class="form-control" name="correo" required>
            </div>
            <div class="mb-3">
                <label for="usuario" class="form-label">Usuario:</label>
                <input type="text" class="form-control" name="usuario" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Contraseña:</label>
                <input type="password" class="form-control" name="password" required>
            </div>
            <button type="submit" name="btn_registro" class="btn btn-primary">Agregar Persona</button>
        </form>
    </div>
    <footer>
        <div class="footer-column">
            <h3>QUIERO DONAR</h3>
            <a href="Donar.php">Donar</a>
        </div>

        <div class="footer-column">
            <h3>INFORMACIÓN</h3>
            <a href="Lifeline.php">Sobre Life Line</a>
            <a href="Requisitos.php">Requisitos</a>
        </div>

        <div class="footer-social">
            <a href="#"><img src="imagenes/ig.png" alt="Icono 1" width="50"></a>
            <a href="#"><img src="imagenes/life.png" alt="Instagram" width="50"></a>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
<?php
include("db.php");

// Obtener el ID del turno a editar
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Procesar el formulario de edición
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_registro = $conexion->real_escape_string($_POST['id_registro']);
    $id_sede = $conexion->real_escape_string($_POST['id_sede']);
    $fecha = $conexion->real_escape_string($_POST['fecha']);
    $hora = $conexion->real_escape_string($_POST['hora']);
    $estado = $conexion->real_escape_string($_POST['estado']);

    $sql = "UPDATE ll_turnos SET id_registro='$id_registro', id_sede='$id_sede', fecha='$fecha', hora='$hora', estado='$estado' WHERE id_turno=$id";

    if ($conexion->query($sql) === TRUE) {
        echo '<div class="alert alert-success">Turno modificado correctamente.</div>';
    } else {
        echo '<div class="alert alert-danger">Error al modificar el turno: ' . $conexion->error . '</div>';
    }
}

// Obtener los datos actuales del turno
$sql = "SELECT * FROM ll_turnos WHERE id_turno=$id";
$resultado = $conexion->query($sql);
$turno = $resultado->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Life Line - Editar Turno</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styleadmin.css">
</head>
<body>
    <div class="container mt-5">
        <div class="card card-edit-turno">
            <h2>Panel de Administración - Editar Turno</h2>
        <form method="post">
            <div class="mb-3">
                <label for="id_registro" class="form-label">ID del Donante</label>
                <input type="number" class="form-control" id="id_registro" name="id_registro" value="<?php echo htmlspecialchars($turno['id_registro']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="id_sede" class="form-label">ID de la Sede</label>
                <input type="number" class="form-control" id="id_sede" name="id_sede" value="<?php echo htmlspecialchars($turno['id_sede']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="fecha" class="form-label">Fecha</label>
                <input type="date" class="form-control" id="fecha" name="fecha" value="<?php echo htmlspecialchars($turno['fecha']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="hora" class="form-label">Hora</label>
                <input type="time" class="form-control" id="hora" name="hora" value="<?php echo htmlspecialchars($turno['hora']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="estado" class="form-label">Estado</label>
                <select class="form-control" id="estado" name="estado" required>
                    <option value="pendiente" <?php echo $turno['estado'] == 'pendiente' ? 'selected' : ''; ?>>Pendiente</option>
                    <option value="completado" <?php echo $turno['estado'] == 'completado' ? 'selected' : ''; ?>>Completado</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Guardar Cambios</button>
            <a href="detalle_donante.php" class="btn btn-secondary">Cancelar</a>
        </form>
        </div>
    </div>
</body>
</html>
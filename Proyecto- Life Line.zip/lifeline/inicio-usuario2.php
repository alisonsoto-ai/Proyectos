<?php
require 'db.php';
session_start();

// 1. Validar sesión usando 'id_usuario'
if (!isset($_SESSION['id_usuario'])) {
    header("Location: login.html");
    exit();
}

$id_registro = $_SESSION['id_usuario'];

// 2. Obtener datos personales del donante desde la tabla 'll_registro'
$sql_donante = "SELECT nombre, apellido, tipo_sangre 
                FROM ll_registro 
                WHERE id_registro = '$id_registro'";

$res_donante = $conexion->query($sql_donante);

if (!$res_donante) {
    die("Error en la consulta de donante: " . $conexion->error);
}

$donante = $res_donante->fetch_assoc();

if (!$donante) {
    die("Donante no encontrado.");
}

// 3. Cantidad de donaciones realizadas
// Ahora utiliza la tabla 'll_turnos'
$sql_cant = "SELECT COUNT(*) AS total 
             FROM ll_turnos 
             WHERE id_registro = '$id_registro' 
             AND estado = 'Realizado'";

$res_cant = $conexion->query($sql_cant);

if (!$res_cant) {
    die("Error en la consulta de donaciones: " . $conexion->error);
}

$cant_donaciones = $res_cant->fetch_assoc()['total'];

// 4. Próxima donación
$sql_proximo = "SELECT fecha 
                FROM ll_turnos 
                WHERE id_registro = '$id_registro' 
                AND fecha >= CURDATE() 
                AND estado != 'Cancelado' 
                ORDER BY fecha ASC 
                LIMIT 1";

$res_proximo = $conexion->query($sql_proximo);

if ($res_proximo && $res_proximo->num_rows > 0) {
    $fila_proximo = $res_proximo->fetch_assoc();
    $proxima_donacion = date('d M', strtotime($fila_proximo['fecha']));
} else {
    $proxima_donacion = "Sin turno";
}

// 5. Estado del donante
$estado_donante = "Activo";
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Life Line - Home</title>
    <link rel="stylesheet" href="style2.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>

<body>

<header class="encabezado">
    <h2 class="logo">LIFE LINE</h2>
    <nav class="menu">
        <a href="inicio-usuario2.php">Inicio</a>
        
        <div class="submenu">
            <a href="sobre-donar2.html">
                Sobre donar 
                <i class="fa-solid fa-chevron-down"></i>
            </a>
            <div class="submenu-contenido">
                <a href="sangre2.html">
                    <i class="fa-solid fa-droplet"></i>
                    Sangre
                </a>
                <a href="plaquetas2.html">
                    <i class="fa-solid fa-hand-holding-medical"></i>
                    Plaquetas
                </a>
                <a href="requisitos2.html">
                    <i class="fa-solid fa-droplet"></i>
                    Requisitos
                </a>
            </div>
        </div>

        <a href="centros2.html">Centros</a>
        
        <div class="submenu">
            <a href="#">
                Información
                <i class="fa-solid fa-chevron-down"></i>
            </a>
            <div class="submenu-contenido">
                <a href="historias.html">
                    <i class="fa-solid fa-book-open"></i>
                    Historias
                </a>
                <a href="preguntas.html">
                    <i class="fa-solid fa-circle-question"></i>
                    Preguntas y Mitos
                </a>
                <a href="colectas.html">
                    <i class="fa-solid fa-house"></i>
                    Colectas
                </a>
            </div>
        </div>

        <a href="sacar_turno.php">Reservar Turnos</a>
        <a href="sobre-nosotros2.html">Nosotros</a>
    </nav>

    <a href="perfil_donante.php" class="icono-usuario">
        <i class="fa-solid fa-user"></i>
    </a>
</header>

<section class="panel-usuario">
    <div class="contenido-panel">

        <div class="informacion-usuario">
            <span class="etiqueta-panel">
                PANEL DE DONANTE
            </span>

            <h1>¡Bienvenido/a, <?php echo htmlspecialchars($donante['nombre']); ?>! 👋</h1>

            <p>
                Nos alegra verte de nuevo. Desde este panel podés gestionar tus
                turnos, consultar tu historial de donaciones y seguir colaborando
                para salvar vidas.
            </p>

            <div class="botones-panel">
                <a href="sacar_turno.php" class="boton-rojo">
                    <i class="fa-solid fa-calendar-plus"></i>
                    Reservar turno
                </a>
                <a href="perfil_donante.php" class="boton-blanco">
                    <i class="fa-solid fa-user"></i>
                    Mi perfil
                </a>
            </div>
        </div>

        <div class="resumen-usuario">

            <div class="tarjeta-resumen">
                <i class="fa-solid fa-heart"></i>
                <h3><?php echo $cant_donaciones; ?></h3>
                <p>Donaciones realizadas</p>
            </div>

            <div class="tarjeta-resumen">
                <i class="fa-solid fa-calendar-check"></i>
                <h3><?php echo $proxima_donacion; ?></h3>
                <p>Próxima donación</p>
            </div>

            <div class="tarjeta-resumen">
                <i class="fa-solid fa-droplet"></i>
                <h3><?php echo htmlspecialchars($donante['tipo_sangre']); ?></h3>
                <p>Grupo sanguíneo</p>
            </div>

            <div class="tarjeta-resumen">
                <i class="fa-solid fa-award"></i>
                <h3><?php echo $estado_donante; ?></h3>
                <p>Estado del donante</p>
            </div>

        </div>

    </div>
</section>
<section class="derechos-donante">
    <div class="contenedor-derechos">
        <span class="etiqueta-seccion">MARCO LEGAL Y BENEFICIOS</span>
        <h2>Tus Derechos como Donante Voluntario</h2>
        <p class="subtitulo-seccion">
            Conocé las protecciones y consideraciones laborales y sociales que te corresponden por ley al realizar tu donación de sangre.
        </p>

        <div class="tarjetas-derechos">

            <div class="tarjeta-derecho">
                <div class="icono-derecho">
                    <i class="fa-solid fa-briefcase"></i>
                </div>
                <h3>Día Laboral Justificado</h3>
                <p>
                    Por la Ley Nacional de Donación de Sangre (N° 22.990), tenés derecho a tomarte el día de la donación sin que se te descuente el salario ni afecte el premio por presentismo.
                </p>
            </div>

            <div class="tarjeta-derecho">
                <div class="icono-derecho">
                    <i class="fa-solid fa-file-medical"></i>
                </div>
                <h3>Certificado Oficial</h3>
                <p>
                    El centro de salud te entregará un comprobante médico oficial al finalizar el proceso para que puedas presentarlo en tu trabajo o establecimiento educativo.
                </p>
            </div>

            <div class="tarjeta-derecho">
                <div class="icono-derecho">
                    <i class="fa-solid fa-shield-halved"></i>
                </div>
                <h3>Confidencialidad Médica</h3>
                <p>
                    Tus estudios clínicos y análisis hematológicos son estrictamente confidenciales. Tenés derecho a recibir los resultados e información sobre tu estado de salud.
                </p>
            </div>

            <div class="tarjeta-derecho">
                <div class="icono-derecho">
                    <i class="fa-solid fa-heart-pulse"></i>
                </div>
                <h3>Atención y Cuidado</h3>
                <p>
                    Tenés derecho a un trato digno, orientación sobre el proceso, uso de material 100% descartable y un descanso post-donación junto con un refrigerio.
                </p>
            </div>

        </div>
    </div>
</section>
<section class="impacto-donacion">
    <div class="contenedor-impacto">
        <span class="etiqueta-seccion">TU IMPACTO</span>
        <h2>¿De qué manera ayudás al donar?</h2>
        <p class="subtitulo-seccion">
            Cada donación de sangre genera un efecto multiplicador que transforma y salva vidas en distintas situaciones críticas.
        </p>

        <div class="lista-impacto">

            
            <div class="item-impacto">
                <div class="imagen-impacto">
                    <img src="imagenes/salvar-vidas.jpg" alt="Salvar hasta 4 vidas">
                </div>
                <div class="texto-impacto">
                    <span class="numero-impacto">01</span>
                    <h3>Salvás hasta 4 vidas con una sola donación</h3>
                    <p>
                        Tu sangre se fracciona en sus distintos componentes: glóbulos rojos, plaquetas, plasma y crioprecipitados. Esto permite que una sola extracción pueda ayudar a cuatro pacientes distintos según sus necesidades médicas específicas.
                    </p>
                </div>
            </div>

            
            <div class="item-impacto inverso">
                <div class="imagen-impacto">
                    <img src="imagenes/urgencias.jpg" alt="Tratamiento de emergencias">
                </div>
                <div class="texto-impacto">
                    <span class="numero-impacto">02</span>
                    <h3>Apoyás en emergencias y cirugías complejas</h3>
                    <p>
                        Las víctimas de accidentes de tránsito, intervenciones quirúrgicas de alta complejidad y trasplantes de órganos requieren transfusiones inmediatas. Contar con stock en los bancos de sangre marca la diferencia entre la vida y la muerte.
                    </p>
                </div>
            </div>

            
            <div class="item-impacto">
                <div class="imagen-impacto">
                    <img src="imagenes/oncologia.jpg" alt="Acompañamiento a pacientes oncologicos">
                </div>
                <div class="texto-impacto">
                    <span class="numero-impacto">03</span>
                    <h3>Acompañás tratamientos oncológicos</h3>
                    <p>
                        Muchos pacientes en tratamiento contra el cáncer o la leucemia necesitan transfusiones continuas de plaquetas y glóbulos rojos para reponer las células que destruye la quimioterapia y poder continuar su recuperación.
                    </p>
                </div>
            </div>

            
            <div class="item-impacto inverso">
                <div class="imagen-impacto">
                    <img src="imagenes/maternidad.jpg" alt="Salud materna e infantil">
                </div>
                <div class="texto-impacto">
                    <span class="numero-impacto">04</span>
                    <h3>Protegés la salud materna e infantil</h3>
                    <p>
                        Las complicaciones durante el parto, las hemorragias obstétricas y los tratamientos para recién nacidos o bebés prematuros requieren disponibilidad constante de sangre segura para salvar la vida de las madres y sus hijos.
                    </p>
                </div>
            </div>

        </div>
    </div>
</section>

<footer class="pie-pagina">
    <div class="contenido-footer">

        <div class="marca-footer">
            <img src="imagenes/logoasd.png" alt="LifeLine" class="logo-footer">
            <p>
                LifeLine conecta donantes con centros de salud para facilitar la
                donación de sangre de forma rápida, segura y accesible.
            </p>
            <div class="redes-footer">
                <a href="#"><i class="fa-brands fa-instagram"></i></a>
                <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
            </div>
        </div>

        <div class="columna-footer">
            <h4>Navegación</h4>
            <a href="#">Inicio</a>
            <a href="#">Requisitos</a>
            <a href="#">Sobre donar</a>
            <a href="#">Centros</a>
            <a href="#">Contacto</a>
        </div>

        <div class="columna-footer">
            <h4>Información</h4>
            <a href="#">Preguntas frecuentes</a>
            <a href="#">Cómo donar</a>
        </div>

        <div class="columna-footer">
            <h4>Contacto</h4>
            <a href="#">lifeline.org@.com</a>
            <a href="#">+54 11 2345-6789</a>
            <a href="#">San Miguel, Buenos Aires</a>
        </div>

    </div>

    <div class="barra-footer">
        <span>© 2026 LifeLine. Todos los derechos reservados.</span>
    </div>
</footer>

</body>
</html>
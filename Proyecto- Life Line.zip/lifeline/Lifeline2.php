<!DOCTYPE html>
<html lang="es">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Life Line - Nosotros</title>

<link rel="stylesheet" href="style2.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

</head>

<body>


<header class="encabezado">

    <h2 class="logo">LIFE LINE</h2>

    <nav class="menu">

        <a href="inicio-usuario2.php">Inicio</a>


        
        <div class="submenu">

            <a href="sobre-donar2.html">
                Sobre donar 
                <i class="fa-solid fa-chevron-down"></i>
            </a>


            <div class="submenu-contenido">

                <a href="sangre2.html">
                    <i class="fa-solid fa-droplet"></i>
                    Sangre
                </a>

                <a href="plaquetas2.html">
                    <i class="fa-solid fa-hand-holding-medical"></i>
                    Plaquetas
                </a>

                <a href="requisitos2.html">
                    <i class="fa-solid fa-droplet"></i>
                    Requisitos
                </a>

            </div>

        </div>


        <a href="centros2.html">Centros</a>


        
        <div class="submenu">

            <a href="#">
                Información
                <i class="fa-solid fa-chevron-down"></i>
            </a>


            <div class="submenu-contenido">

                <a href="historias.html">
                    <i class="fa-solid fa-book-open"></i>
                    Historias
                </a>


                <a href="preguntas.html">
                    <i class="fa-solid fa-circle-question"></i>
                    Preguntas y Mitos
                </a>
                <a href="colectas.html">
                    <i class="fa-solid fa-house"></i>
                    Colectas
                </a>

            </div>

        </div>


        <a href="sacar_turno.php">Reservar Turnos</a>

        <a href="sobre-nosotros2.html">Nosotros</a>


    </nav>


    
    <a href="perfil.html" class="icono-usuario">

        <i class="fa-solid fa-user"></i>

    </a>


</header>



<!-- HERO -->

<section class="hero-nosotros">

    <div class="hero-texto">

        <h1>¿Quiénes somos?</h1>

        <p>
            Life Line surge como una iniciativa de jóvenes comprometidos con la solidaridad y la salud pública, diseñada especialmente para FUHESA. Nuestra plataforma busca cerrar la brecha entre la oferta y la demanda de sangre en Argentina, haciendo que donar sea simple, seguro y accesible.
        </p>

    </div>


    <div class="hero-gota">
        <img src="imagenes/gota.png" alt="Gota de sangre">
    </div>

</section>



<!-- SOBRE NOSOTROS -->

<section class="seccion-nosotros">

    <div class="tarjetas-nosotros">

        <div class="tarjeta-info">

            <i class="fa-solid fa-user-group"></i>

            <h3>Para donantes</h3>

            <p>
                Encontrá requisitos, información importante y centros
                disponibles para donar sangre.
            </p>

            <p>
                Gestioná tus turnos de manera fácil desde un solo lugar.
            </p>

        </div>



        <div class="tarjeta-info">

            <i class="fa-solid fa-hospital"></i>

            <h3>Para FUHESA</h3>

            <p>
                Una herramienta digital para mejorar la organización
                de campañas y donaciones.
            </p>

            <p>
                Permite conectar la fundación con una comunidad más activa.
            </p>

        </div>

    </div>

</section>



<!-- ESTADISTICAS -->

<section class="estadisticas">

    <div class="dato">

        <i class="fa-solid fa-droplet"></i>

        <h2>+1000</h2>

        <p>Donantes conectados</p>

    </div>


    <div class="dato">

        <i class="fa-solid fa-calendar-check"></i>

        <h2>24/7</h2>

        <p>Información disponible</p>

    </div>


    <div class="dato">

        <i class="fa-solid fa-heart"></i>

        <h2>100%</h2>

        <p>Compromiso solidario</p>

    </div>

</section>



<!-- FUHESA -->

<section class="seccion-fuhesa">

    <div class="contenido-fuhesa">

        <div class="imagen-fuhesa">
            <img src="imagenes/fuhesa.png" alt="Fundación FUHESA">
        </div>


        <div class="texto-fuhesa">

            <span>Nuestra alianza</span>

            <h2>Sobre FUHESA</h2>

            <p>
                FUHESA es una fundación comprometida con la promoción
                de la donación voluntaria de sangre y el fortalecimiento
                del sistema de salud argentino. 
                Trabaja junto a donantes, instituciones y comunidades
                para garantizar el acceso a sangre segura para quienes
                la necesitan.
            </p>

            <p>
                Life Line acompaña esta misión ofreciendo una herramienta
                digital que facilita la comunicación, organización y
                participación.
            </p>

            <a href="https://fuhesa.org.ar/#!/-inicio/" class="btn-rojo">
                Conocer FUHESA
            </a>

        </div>

    </div>

</section>
<footer class="pie-pagina">

    <div class="contenido-footer">

        <div class="marca-footer">

            <img src="imagenes/logoasd.png" alt="LifeLine" class="logo-footer">

            <p>
                LifeLine conecta donantes con centros de salud para facilitar la
                donación de sangre de forma rápida, segura y accesible.
            </p>

            <div class="redes-footer">

                <a href="#"><i class="fa-brands fa-instagram"></i></a>
                <a href="#"><i class="fa-brands fa-facebook-f"></i></a>

            </div>

        </div>

        <div class="columna-footer">

            <h4>Navegación</h4>

            <a href="#">Inicio</a>
            <a href="#">Requisitos</a>
            <a href="#">Sobre donar</a>
            <a href="#">Centros</a>
            <a href="#">Contacto</a>

        </div>

        <div class="columna-footer">

            <h4>Información</h4>

            <a href="#">Preguntas frecuentes</a>
            <a href="#">Cómo donar</a>

        </div>

        <div class="columna-footer">

            <h4>Contacto</h4>

            <a href="#">contacto@lifeline.com</a>
            <a href="#">+54 11 2345-6789</a>
            <a href="#">San Miguel, Buenos Aires</a>

        </div>

    </div>

    <div class="barra-footer">

        <span>© 2026 LifeLine. Todos los derechos reservados.</span>

    </div>

</footer>


</body>
</html>
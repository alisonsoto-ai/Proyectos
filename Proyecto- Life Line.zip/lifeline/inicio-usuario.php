<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Life Line - Home</title>

    <link rel="stylesheet" href="style.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>

<body>

<header class="encabezado">

    <h2 class="logo">LIFE LINE</h2>

    <nav class="menu">
        <a href="inicio-usuario.php">Inicio</a>
        <a href="#requisitos">Requisitos</a>

        <div class="submenu">
            <a href="sobre-donar.html">
                Sobre donar <i class="fa-solid fa-chevron-down"></i>
            </a>

            <div class="submenu-contenido">
                <a href="sangre.html">
                    <i class="fa-solid fa-droplet"></i> Sangre
                </a>

                <a href="plaquetas.html">
                    <i class="fa-solid fa-hand-holding-medical"></i> Plaquetas
                </a>
            </div>
        </div>
        <a href="como-funciona.html">Como funciona</a>
        <a href="centros.html">Centros</a>
        <a href="sobre-nostros.html">Nosotros</a>
    </nav>

    <a href="login.html" class="boton-iniciar">Iniciar sesión</a>

</header>
    <section class="portada">

        <div class="filtro"></div>

        <div class="contenido">

            <h1>Salvá vidas en el lugar justo y a tiempo</h1>

            <p>
                Con solo una donación podés ayudar a salvar vidas. Formá parte del sistema de salud y asegurá la disponibilidad sanguínea donde más se necesita.

            <div class="botones">
                <a href="centros.html" class="boton-blanco">Conocer más</a>

                <a href="login.html" class="boton-rojo">Quiero unirme</a>
            </div>

        </div>

    </section>

<section class="seccion-requisitos" id="requisitos">

    <div class="fondo-decorativo"></div>

    <div class="encabezado-requisitos">

        <span>Antes de donar</span>

        <h2>¿Estoy capacitado para donar?</h2>

        <p>
         Donar sangre es un acto voluntario y seguro, pero no todos pueden hacerlo. Conocé los requisitos básicos que garantizan tu seguridad y la del donatario.
        </p>
        <div class="boton-requisitos">
        <a href="login.html">Quiero donar</a>
        </div>

    </div>


    <div class="contenedor-requisitos">

        <article class="tarjeta-requisito">

            <span class="numero-requisito">01</span>

            <div class="icono-requisito">
                <i class="fa-solid fa-user"></i>
            </div>

            <h3>Edad</h3>

            <p>Tener entre 16 y 65 años.</p>

        </article>

        <article class="tarjeta-requisito">

            <span class="numero-requisito">02</span>

            <div class="icono-requisito">
                <i class="fa-solid fa-weight-scale"></i>
            </div>

            <h3>Peso</h3>

            <p>Pesar más de 50 kg.</p>

        </article>

        <article class="tarjeta-requisito">

            <span class="numero-requisito">03</span>

            <div class="icono-requisito">
                <i class="fa-solid fa-heart-pulse"></i>
            </div>

            <h3>Estado de salud</h3>

            <p>Sentirte bien y no presentar síntomas de enfermedad.</p>

        </article>

        <article class="tarjeta-requisito">

            <span class="numero-requisito">04</span>

            <div class="icono-requisito">
                <i class="fa-solid fa-utensils"></i>
            </div>

            <h3>Alimentación</h3>

            <p>Haber desayunado o almorzado antes de donar.</p>

        </article>

        <article class="tarjeta-requisito">

            <span class="numero-requisito">05</span>

            <div class="icono-requisito">
                <i class="fa-solid fa-bed"></i>
            </div>

            <h3>Descanso</h3>

            <p>Dormir al menos seis horas la noche anterior.</p>

        </article>

        <article class="tarjeta-requisito">

            <span class="numero-requisito">06</span>

            <div class="icono-requisito">
                <i class="fa-solid fa-droplet"></i>
            </div>

            <h3>Hidratación</h3>

            <p>Tomar abundante agua antes de asistir.</p>

        </article>

        
        <article class="tarjeta-requisito">

            <span class="numero-requisito">07</span>

            <div class="icono-requisito">
                <i class="fa-solid fa-calendar"></i>
            </div>

            <h3>Frecuencia</h3>

            <p>Esperar 8 semanas entre donaciones.</p>

        </article>

        <article class="tarjeta-requisito">

            <span class="numero-requisito">08</span>

            <div class="icono-requisito">
                <i class="fa-solid fa-pills"></i>
            </div>

            <h3>Medicamentos</h3>

            <p>No haber tomado aspirinas o antiinflamatorios en los últimos 5 días.</p>

        </article>

        <article class="tarjeta-requisito">

            <span class="numero-requisito">09</span>

            <div class="icono-requisito">
                <i class="fa-regular fa-file-contract"></i>
            </div>

            <h3>Documentación</h3>

            <p>Presentar DNI u otra documentación con fotografía que acredite identidad.</p>

        </article>
    </div>
</section>

<section class="seccion-como-funciona">

    <div class="filtro-como-funciona"></div>

    <div class="contenido-como-funciona">

        <span class="etiqueta-como-funciona">
            ¿CÓMO FUNCIONA?
        </span>

        <h2>
            Descubrí cómo LifeLine conecta donantes con quienes más lo necesitan.
        </h2>

        <p>
            Conocé cada etapa del proceso, desde la verificación de requisitos
            hasta la reserva de un turno. Todo explicado de forma simple para
            que donar sangre sea una experiencia rápida, segura y organizada.
        </p>

        <a href="como-funciona.html" class="boton-como-funciona">
            Conocer el funcionamiento
            <i class="fa-solid fa-arrow-right"></i>
        </a>

    </div>

</section>
<section class="seccion-contacto" id="contacto">

    <div class="gota-sangre gota-1"></div>
    <div class="gota-sangre gota-2"></div>
    <div class="gota-sangre gota-3"></div>
    <div class="gota-sangre gota-4"></div>

    <div class="contenido-contacto">

        <div class="informacion-contacto">

            <span class="etiqueta-contacto">
                CONTACTANOS
            </span>

            <h2>¿Tenés alguna duda?</h2>

            <p>
                Nuestro equipo está listo para ayudarte con cualquier consulta
                sobre la donación de sangre, requisitos o centros de donación.
            </p>

            <div class="dato-contacto">

                <div class="icono-contacto">
                    <i class="fa-solid fa-phone"></i>
                </div>

                <div>
                    <h4>Instagram</h4>
                    <span>lifeline.arg</span>
                </div>

            </div>

            <div class="dato-contacto">

                <div class="icono-contacto">
                    <i class="fa-solid fa-envelope"></i>
                </div>

                <div>
                    <h4>Email</h4>
                    <span>lifelineoficial.org@gmail.com</span>
                </div>

            </div>

            <div class="dato-contacto">

                <div class="icono-contacto">
                    <i class="fa-solid fa-location-dot"></i>
                </div>

                <div>
                    <h4>Ubicación</h4>
                    <span>San Miguel, Buenos Aires</span>
                </div>

            </div>

        </div>

        <form class="formulario-contacto">

            <input type="text" placeholder="Nombre completo">

            <input type="email" placeholder="Correo electrónico">

            <input type="text" placeholder="Asunto">

            <textarea placeholder="Escribí tu mensaje..."></textarea>

            <button type="submit">
                Enviar mensaje
            </button>

        </form>

    </div>

</section>

<footer class="pie-pagina">

    <div class="contenido-footer">

        <div class="marca-footer">

            <img src="imagenes/logoasd.png" alt="LifeLine" class="logo-footer">

            <p>
                LifeLine conecta donantes con centros de salud para facilitar la
                donación de sangre de forma rápida, segura y accesible.
            </p>

            <div class="redes-footer">

                <a href="https://www.instagram.com/lifeline.arg/"><i class="fa-brands fa-instagram"></i></a>
                <a href="#"><i class="fa-brands fa-facebook-f"></i></a>

            </div>

        </div>

        <div class="columna-footer">

            <h4>Navegación</h4>

            <a href="inicio-usuario.php">Inicio</a>
            <a href="#requisitos">Requisitos</a>
            <a href="lifeline.php">Sobre donar</a>
            <a href="centros.html">Centros</a>
            <a href="#contacto">Contacto</a>

        </div>

        <div class="columna-footer">

            <h4>Información</h4>

            <a href="preguntas.html">Preguntas frecuentes</a>
            <a href="como-funciona.html">Cómo donar</a>

        </div>

        <div class="columna-footer">

            <h4>Contacto</h4>

            <a href="#">lifelineoficial@gmail.com</a>
            <a href="#">+54 11 63568580</a>
            <a href="#">San Miguel, Buenos Aires</a>

        </div>

    </div>

    <div class="barra-footer">

        <span>© 2026 LifeLine. Todos los derechos reservados.</span>

    </div>

</footer>
</body>

</html>
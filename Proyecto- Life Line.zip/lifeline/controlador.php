<?php


// --- CONFIGURACIÓN INICIAL ---
session_start();
require_once("db.php");// Debe definir la variable $conexion (objeto mysqli)

// Verificar conexión
if (!$conexion) {
    die("Error: no se pudo conectar a la base de datos.");
}


// --- FUNCIÓN REUTILIZABLE PARA VERIFICAR LOGIN ---
// La función solo verifica y setea la sesión, no redirige.
function verificarLogin($conexion, $tabla, $campo_usuario, $campo_id, $usuario, $password) {
    
    // Sentencia SQL preparada
    $sql = "SELECT $campo_id, password FROM $tabla WHERE $campo_usuario = ?";
    $stmt = $conexion->prepare($sql);

    // Verificación de preparación, enlace y ejecución
    if ($stmt && $stmt->bind_param("s", $usuario) && $stmt->execute()) {
        $resultado = $stmt->get_result();

        // Si existe un solo registro coincidente
        if ($resultado->num_rows === 1) {
            $datos = $resultado->fetch_object();

            // Verificar la contraseña
            if ($password === $datos->password) {
                
                // Éxito: Iniciar sesión segura
                session_regenerate_id(true);
                $_SESSION[$campo_id] = $datos->$campo_id;
                
                $stmt->close();
                return true; // Éxito
            }
        }
    }
  
    // Liberar recursos
    if (isset($stmt)) {
        $stmt->close();
    }

    return false; // Fallo
}


/// --- PROCESO PRINCIPAL ---

if (isset($_POST["btn_login"])) {

    // Limpiar y sanitizar entradas del usuario
    $usuario = substr(trim($_POST["usuario"]), 0, 50); 
    $txt_password = $_POST["password"];

    // Validar que no estén vacíos
    if (empty($usuario) || empty($txt_password)) {
        header("Location: error.html?tipo=campos_vacios");
        exit;
    }

    // 1. Intentar login en tabla 'll_usuario'
    if (verificarLogin(
        $conexion,
        'll_usuario',
        'usuario',
        'id_usuario',
        $usuario,
        $txt_password
    )) {
        header("Location: inicio-usuario2.php");
        exit;
    }

    // 2. Intentar login en tabla 'll_sede'
    if (verificarLogin(
        $conexion,
        'll_sede',
        'nombre_sede',
        'id_sede',
        $usuario,
        $txt_password
    )) {
        header("Location: paneladmin.html");
        exit;
    }

    // Si no se encontró coincidencia en ninguna tabla
    header("Location: error.html?tipo=credenciales");
    exit;
}

// Cierre de la conexión
if (isset($conexion)) {
    $conexion->close();
}

?>
<html>
<head>
   <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Requisitos-Life Line</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">

</head>
<body class="fondo">
<header class="header">
    <div class="logo">
        <img src="imagenes/logo.png" alt="Life Line Logo"><p class="life">Life Line</p>
    </div>
    <nav>
        <ul class="nav-links">
           <li><a href="index.php">Inicio</a></li>
            <li><a href="Requisitos.php">Requisitos</a></li>
            <li><a href="Donar.php">Donar</a></li>
            <li><a href="Lifeline.php">Sobre Life Line</a></li>
            <li><a href="#contacto">Contacto</a></li>

        </ul>
    </nav>
    <a href="#" class="btn-registrarse">Iniciar Sesión</a>
</header>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enviar Alerta de Sangre</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styleadmin.css">
</head>
<body>
    <header class="headeradmin">
        <div class="logo">
            <img src="imagenes/imagenlogolifeline.png" alt="Life Line Logo">
        </div>
        <nav>
            <ul class="nav-links">
                <li><a href="admin.php">Lista de donantes</a></li>
                <li><a href="admin_alerta.php">Alertas</a></li>
            </ul>
        </nav>
    </header>

    <div class="container mt-5">
        <h2>Enviar Alerta de Donación</h2>

        <form method="POST" action="">
            <div class="mb-3">
                <label for="tipo_sangre" class="form-label">Tipo de Sangre</label>
                <select class="form-select" id="tipo_sangre" name="tipo_sangre" required>
                    <option value="">Selecciona un tipo de sangre</option>
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                    <option value="RH-">RH-</option>
                </select>
            </div>

            <div class="mb-3">
                <label for="id_sede" class="form-label">Sede</label>
                <select class="form-control" id="id_sede" name="id_sede" required>
                    <option value="">-- Selecciona una sede --</option>

                    <?php
                    require 'db.php';

                    $sql_sedes = $conexion->query(
                        "SELECT id_sede, nombre_sede FROM ll_sede"
                    );

                    while ($sede = $sql_sedes->fetch_object()) {
                        echo "<option value='$sede->id_sede'>$sede->nombre_sede</option>";
                    }
                    ?>

                </select>
            </div>

            <div class="mb-3">
                <label for="mensaje" class="form-label">Mensaje</label>
                <textarea class="form-control" id="mensaje" name="mensaje" required></textarea>
            </div>

            <button type="submit" class="btn btn-primary">Enviar Alerta</button>
        </form>

        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            require 'db.php';

            $tipo_sangre = $_POST['tipo_sangre'];
            $id_sede = $_POST['id_sede'];
            $mensaje_personalizado = $_POST['mensaje'];

            // Obtener nombre de la sede
            $stmt_sede = $conexion->prepare(
                "SELECT nombre_sede 
                 FROM ll_sede 
                 WHERE id_sede = ?"
            );

            $stmt_sede->bind_param("i", $id_sede);
            $stmt_sede->execute();

            $resultado_sede = $stmt_sede->get_result();
            $sede = $resultado_sede->fetch_assoc();

            if (!$sede) {
                die("<p class='text-danger'>No se encontró la sede seleccionada.</p>");
            }

            // Buscar usuarios por tipo de sangre
            $stmt = $conexion->prepare("
                SELECT correo 
                FROM ll_registro 
                WHERE tipo_sangre = ?
            ");

            $stmt->bind_param("s", $tipo_sangre);
            $stmt->execute();

            $resultado = $stmt->get_result();

            $subject = "URGENTE: Se necesita sangre tipo $tipo_sangre";

            $message = $mensaje_personalizado .
                       " En la sede " .
                       $sede['nombre_sede'] .
                       ".";

            $headers = 'From: lifelineoficial.org@gmail.com' . "\r\n";

            if ($resultado && $resultado->num_rows > 0) {

                while ($fila = $resultado->fetch_assoc()) {

                    $to = $fila['correo'];

                    if (mail($to, $subject, $message, $headers)) {
                        echo "<p class='text-success'>Correo enviado a: $to</p>";
                    } else {
                        echo "<p class='text-danger'>Error al enviar correo a: $to</p>";
                    }
                }

                // Registrar la alerta en la base de datos
                $stmt_insert = $conexion->prepare("
                    INSERT INTO ll_alertas
                    (tipo_sangre, id_sede, mensaje, fecha_envio)
                    VALUES (?, ?, ?, NOW())
                ");

                $stmt_insert->bind_param(
                    "sis",
                    $tipo_sangre,
                    $id_sede,
                    $mensaje_personalizado
                );

                $stmt_insert->execute();

                echo "<p class='text-info mt-3'>
                        ✅ Proceso completado y alerta registrada.
                      </p>";

            } else {

                echo "<p class='text-warning'>
                        ⚠️ No se encontraron usuarios con ese tipo de sangre.
                      </p>";
            }

            $conexion->close();
        }
        ?>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['id_turno'], $_POST['estado'])) {
        die('Faltan datos.');
    }

    $id_turno = intval($_POST['id_turno']);
    $estado = $_POST['estado'];

    // Actualizar el estado del turno
    $stmt = $conexion->prepare("UPDATE ll_turnos SET estado = ? WHERE id_turno = ?");
    $stmt->bind_param("si", $estado, $id_turno);

    if ($stmt->execute()) {

        // Enviar correo de agradecimiento al marcar "Completado"
        if (strtolower($estado) === 'completado') {
            $sql = "
                SELECT t.id_turno, r.nombre, r.apellido, r.correo, t.fecha, t.hora
                FROM ll_turnos t
                INNER JOIN ll_registro r ON t.id_registro = r.id_registro
                WHERE t.id_turno = ? 
                AND (t.agradecimiento_enviado = 0 OR t.agradecimiento_enviado IS NULL)
            ";

            $stmt2 = $conexion->prepare($sql);
            $stmt2->bind_param("i", $id_turno);
            $stmt2->execute();
            $resultado = $stmt2->get_result();

            if ($resultado && $resultado->num_rows > 0) {
                $turno = $resultado->fetch_assoc();

                $to = $turno['correo'];
                $nombre = $turno['nombre'] . ' ' . $turno['apellido'];
                $fecha = $turno['fecha'];
                $hora = $turno['hora'];

                $subject = "¡Gracias por tu donación!";
                $message = "Hola $nombre,\n\n".
                           "Queremos agradecerte por tu donación realizada el día $fecha a las $hora.\n".
                           "Tu generosidad salva vidas. ❤️\n\n".
                           "Con gratitud,\nEl equipo de Life Line.";

                $headers = "From: lifelineoficial.org@gmail.com\r\n";

                if (mail($to, $subject, $message, $headers)) {
                    $update = $conexion->prepare(
                        "UPDATE ll_turnos SET agradecimiento_enviado = 1 WHERE id_turno = ?"
                    );
                    $update->bind_param("i", $id_turno);
                    $update->execute();
                }
            }
        }

        echo 'ok';

    } else {
        echo 'error';
    }

    $stmt->close();
    $conexion->close();
}
?>
<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $correo = $_POST['correo'];
    $nombre = $_POST['nombre'];

    if (!$correo || !$nombre) {
        die('Faltan datos');
    }

    $asunto = "¡Ya podés volver a donar sangre!";
    $mensaje = "Hola $nombre,\n\nHan pasado 90 días desde tu última donación. ¡Ya podés volver a donar sangre y salvar más vidas! ❤️\n\nGracias por ser parte de Lifeline.\n\nEquipo Lifeline";
    $cabeceras = "From: lifelineoficial.org@gmail.com\r\n";

    if (mail($correo, $asunto, $mensaje, $cabeceras)) {
        echo 'ok';
    } else {
        echo 'error';
    }
}
?>

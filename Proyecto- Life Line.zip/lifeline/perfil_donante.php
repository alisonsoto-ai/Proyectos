<?php
require 'db.php'; // tu conexión a la base de datos
session_start();

// Verificamos si el usuario o el admin está logueado
if (isset($_SESSION['id_usuario'])) {
    $id_usuario = $_SESSION['id_usuario'];
    
} else {
    // Si no hay sesión activa, redirigir al login
    header("Location: login.html");
    exit;
}

$id_registro = $_SESSION['id_usuario'];

// Obtener información del donante
$sql_donante = "SELECT nombre, apellido, tipo_sangre, correo, dni FROM ll_registro WHERE id_registro = ?";
$stmt = $conexion->prepare($sql_donante);
$stmt->bind_param("i", $id_registro);
$stmt->execute();
$result_donante = $stmt->get_result();
$donante = $result_donante->fetch_assoc();

if (!$donante) {
    die("Donante no encontrado.");
}

// Obtener historial de turnos (donaciones)
$sql_turnos = "
    SELECT t.id_turno, t.fecha, t.hora, t.estado, s.nombre_sede, t.tipo_donacion 
    FROM ll_turnos t
    INNER JOIN ll_sede s ON t.id_sede = s.id_sede
    WHERE t.id_registro = ?
    ORDER BY t.fecha DESC
";

$stmt2 = $conexion->prepare($sql_turnos);
$stmt2->bind_param("i", $id_registro);
$stmt2->execute();
$result_turnos = $stmt2->get_result();
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historial de Donaciones</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style2.css">
</head>

<body class="fondo-historial">
    <header class="encabezado">

    <h2 class="logo">LIFE LINE</h2>

    <nav class="menu">

        <a href="inicio-usuario2.php">Inicio</a>


        
        <div class="submenu">

            <a href="sobre-donar2.html">
                Sobre donar 
                <i class="fa-solid fa-chevron-down"></i>
            </a>


            <div class="submenu-contenido">

                <a href="sangre2.html">
                    <i class="fa-solid fa-droplet"></i>
                    Sangre
                </a>

                <a href="plaquetas2.html">
                    <i class="fa-solid fa-hand-holding-medical"></i>
                    Plaquetas
                </a>

                <a href="requisitos2.html">
                    <i class="fa-solid fa-droplet"></i>
                    Requisitos
                </a>

            </div>

        </div>


        <a href="centros2.html">Centros</a>


        
        <div class="submenu">

            <a href="">
                Información
                <i class="fa-solid fa-chevron-down"></i>
            </a>


            <div class="submenu-contenido">

                <a href="historias.html">
                    <i class="fa-solid fa-book-open"></i>
                    Historias
                </a>


                <a href="preguntas.html">
                    <i class="fa-solid fa-circle-question"></i>
                    Preguntas y Mitos
                </a>
                <a href="colectas.html">
                    <i class="fa-solid fa-house"></i>
                    Colectas
                </a>

            </div>

        </div>


        <a href="sacar_turno.php">Reservar Turnos</a>

        <a href="sobre-nosotros2.html">Nosotros</a>


    </nav>


    
    <a href="perfil_donante.html" class="icono-usuario">

        <i class="fa-solid fa-user"></i>

    </a>


    </header>
    <div class="card card-edit-turno container mt-5">
        <h2>Historial de Donaciones</h2>

        <div class="card p-3 mb-4">
            <h4><?php echo htmlspecialchars($donante['nombre'] . " " . $donante['apellido']); ?></h4>
            <p><strong>Tipo de Sangre:</strong> <?php echo htmlspecialchars($donante['tipo_sangre']); ?></p>
            <p><strong>Correo:</strong> <?php echo htmlspecialchars($donante['correo']); ?></p>
            <p><strong>DNI:</strong> <?php echo htmlspecialchars($donante['dni']); ?></p>
        </div>

        <h4>Historial de Donaciones</h4>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Fecha</th>
                    <th>Hora</th>
                    <th>Sede</th>
                    <th>Tipo de Donación</th>
                    <th>Estado</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result_turnos->num_rows > 0): ?>
                    <?php while ($turno = $result_turnos->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($turno['fecha']); ?></td>
                            <td><?php echo htmlspecialchars($turno['hora']); ?></td>
                            <td><?php echo htmlspecialchars($turno['nombre_sede']); ?></td>
                            <td><?php echo htmlspecialchars($turno['tipo_donacion']); ?></td>
                            <td><?php echo htmlspecialchars($turno['estado']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" class="text-center">No tienes donaciones registradas.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

<footer class="pie-pagina">

    <div class="contenido-footer">

        <div class="marca-footer">

            <img src="imagenes/logoasd.png" alt="LifeLine" class="logo-footer">

            <p>
                LifeLine conecta donantes con centros de salud para facilitar la
                donación de sangre de forma rápida, segura y accesible.
            </p>

            <div class="redes-footer">

                <a href="#"><i class="fa-brands fa-instagram"></i></a>
                <a href="#"><i class="fa-brands fa-facebook-f"></i></a>

            </div>

        </div>

        <div class="columna-footer">

            <h4>Navegación</h4>

            <a href="#">Inicio</a>
            <a href="#">Requisitos</a>
            <a href="#">Sobre donar</a>
            <a href="#">Centros</a>
            <a href="#">Contacto</a>

        </div>

        <div class="columna-footer">

            <h4>Información</h4>

            <a href="#">Preguntas frecuentes</a>
            <a href="#">Cómo donar</a>

        </div>

        <div class="columna-footer">

            <h4>Contacto</h4>

            <a href="#">lifeline.org@.com</a>
            <a href="#">+54 11 2345-6789</a>
            <a href="#">San Miguel, Buenos Aires</a>

        </div>

    </div>

    <div class="barra-footer">

        <span>© 2026 LifeLine. Todos los derechos reservados.</span>

    </div>

</footer>
</body>
</html>
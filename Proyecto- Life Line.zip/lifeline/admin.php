<?php

session_start();

// Verificamos si el usuario o el admin está logueado
if (isset($_SESSION['id_sede'])) {
    $id_sede = $_SESSION['id_sede'];
} else {
    // Si no hay sesión activa, redirigir al login
    header("Location: login.html");
    exit;
}
?>




<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Life Line</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styleadmin.css">
</head>

<body>
    <header class="headeradmin">
        <div class="logo">
            <img src="imagenes/imagenlogolifeline.png" alt="Life Line Logo">
        </div>
        <nav>
            <ul class="nav-links">
                <li><a href="admin.php">Lista de donantes</a></li>
                <li><a href="admin_alerta.php">Alertas</a></li>
            </ul>
        </nav>
    </header>
    <div class="container mt-5">
        <h2>Panel de Administración - Sedes</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre de la Sede</th>
                    <th>Localidad</th>
                    <th>Teléfono</th>
                    <th>Contraseña</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include("db.php");
                $sql = $conexion->query(" SELECT * FROM ll_sede ");
                while ($datos = $sql->fetch_object()) {
                ?>
                    <tr>
                        <td><?php echo $datos->id_sede; ?></td>
                        <td><?php echo $datos->nombre_sede; ?></td>
                        <td><?php echo $datos->Localidad_sede; ?></td>
                        <td><?php echo $datos->telefono_sede; ?></td>
                        <td><?php echo $datos->password; ?></td>
                        <td>
                            <a href="editar.php?id=<?php echo $datos->id_sede; ?>" class="btn btn-primary btn-sm">Editar</a>
                        </td>
                    </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
    </div>
    <br><br>
    <div class="container mt-5">
        <h2>Panel de Administración - Donantes</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>Correo</th>
                    <th>Teléfono</th>
                    <th>Tipo de Sangre</th>
                    <th>DNI</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include("db.php");
                $sql = $conexion->query("SELECT * FROM ll_registro");
                while ($datos = $sql->fetch_object()) {
                ?>
                    <tr>
                        <td><?php echo $datos->id_registro; ?></td>
                        <td><?php echo $datos->nombre; ?></td>
                        <td><?php echo $datos->apellido; ?></td>
                        <td><?php echo $datos->correo; ?></td>
                        <td><?php echo $datos->telefono; ?></td>
                        <td><?php echo $datos->tipo_sangre; ?></td>
                        <td><?php echo $datos->dni; ?></td>
                        <td>
                            <a href="editar_donante.php?id=<?php echo $datos->id_registro; ?>" class="btn btn-primary btn-sm">Editar</a>
                            <a href="detalle_donante.php?id_registro=<?php echo $datos->id_registro; ?>" class="btn btn-primary btn-sm">Detalle</a>
                        </td>
                    </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
    </div>
    
</body>

</html>
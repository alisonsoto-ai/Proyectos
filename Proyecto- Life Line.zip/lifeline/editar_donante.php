<?php
include("db.php");

// Obtener el ID del donante a editar
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Procesar el formulario de edición
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $conexion->real_escape_string($_POST['nombre']);
    $apellido = $conexion->real_escape_string($_POST['apellido']);
    $correo = $conexion->real_escape_string($_POST['correo']);
    $telefono = $conexion->real_escape_string($_POST['telefono']);
    $tipo_sangre = $conexion->real_escape_string($_POST['tipo_sangre']);
    $dni = $conexion->real_escape_string($_POST['dni']);

    $sql = "UPDATE ll_registro SET nombre='$nombre', apellido='$apellido', correo='$correo', telefono='$telefono', tipo_sangre='$tipo_sangre', dni='$dni' WHERE id_registro=$id";
    
    if ($conexion->query($sql) === TRUE) {
        echo '<div class="alert alert-success">Donante modificado correctamente.</div>';
    } else {
        echo '<div class="alert alert-danger">Error al modificar el donante: ' . $conexion->error . '</div>';
    }
}

// Obtener los datos actuales del donante
$sql = "SELECT * FROM ll_registro WHERE id_registro=$id";
$resultado = $conexion->query($sql);
$donante = $resultado->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Life Line - Editar Donante</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Panel de Administración - Editar Donante</h2>
        <form method="post">
            <div class="mb-3">
                <label for="nombre" class="form-label">Nombre</label>
                <input type="text" class="form-control" id="nombre" name="nombre" value="<?php echo htmlspecialchars($donante['nombre']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="apellido" class="form-label">Apellido</label>
                <input type="text" class="form-control" id="apellido" name="apellido" value="<?php echo htmlspecialchars($donante['apellido']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="correo" class="form-label">Correo</label>
                <input type="email" class="form-control" id="correo" name="correo" value="<?php echo htmlspecialchars($donante['correo']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="telefono" class="form-label">Teléfono</label>
                <input type="text" class="form-control" id="telefono" name="telefono" value="<?php echo htmlspecialchars($donante['telefono']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="tipo_sangre" class="form-label">Tipo de Sangre</label>
                <select class="form-control" id="tipo_sangre" name="tipo_sangre" required>
                    <option value="" <?php echo empty($donante['tipo_sangre']) ? 'selected' : ''; ?>>-- Selecciona --</option>
                    <option value="A+" <?php echo $donante['tipo_sangre'] == 'A+' ? 'selected' : ''; ?>>A+</option>
                    <option value="A-" <?php echo $donante['tipo_sangre'] == 'A-' ? 'selected' : ''; ?>>A-</option>
                    <option value="B+" <?php echo $donante['tipo_sangre'] == 'B+' ? 'selected' : ''; ?>>B+</option>
                    <option value="B-" <?php echo $donante['tipo_sangre'] == 'B-' ? 'selected' : ''; ?>>B-</option>
                    <option value="AB+" <?php echo $donante['tipo_sangre'] == 'AB+' ? 'selected' : ''; ?>>AB+</option>
                    <option value="AB-" <?php echo $donante['tipo_sangre'] == 'AB-' ? 'selected' : ''; ?>>AB-</option>
                    <option value="O+" <?php echo $donante['tipo_sangre'] == 'O+' ? 'selected' : ''; ?>>O+</option>
                    <option value="O-" <?php echo $donante['tipo_sangre'] == 'O-' ? 'selected' : ''; ?>>O-</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="dni" class="form-label">DNI</label>
                <input type="text" class="form-control" id="dni" name="dni" value="<?php echo htmlspecialchars($donante['dni']); ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Guardar Cambios</button>
            <a href="admin.php" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>
</body>
</html>
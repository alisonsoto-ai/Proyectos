<?php
// --- CONFIGURACIÓN DE CONEXIÓN ---
// Parámetros de conexión (podés ajustarlos según tu entorno)
$servidor = "localhost";
$usuario = "root";
$contrasena = "";
$base_datos = "lifeline";



// --- CONEXIÓN CON MYSQL ---
$conexion = new mysqli($servidor, $usuario, $contrasena, $base_datos);


?>
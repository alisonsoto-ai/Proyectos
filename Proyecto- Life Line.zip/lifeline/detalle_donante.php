<?php

require 'db.php';

session_start();


// Verificamos si el usuario está logueado
if (isset($_SESSION['id_usuario'])) {

    // El id_usuario coincide con el id_registro
    $id_registro = $_SESSION['id_usuario'];

} else {

    // Si no hay sesión activa, redirigir al login
    header("Location: login.html");
    exit;
}


// Obtener información del donante
$sql_donante = "
    SELECT nombre, apellido, tipo_sangre, correo, dni
    FROM ll_registro
    WHERE id_registro = ?
";

$stmt = $conexion->prepare($sql_donante);

$stmt->bind_param("i", $id_registro);

$stmt->execute();

$result_donante = $stmt->get_result();

$donante = $result_donante->fetch_assoc();


if (!$donante) {
    die("Donante no encontrado.");
}


// Obtener historial de turnos (donaciones)
$sql_turnos = "
    SELECT 
        t.id_turno,
        t.fecha,
        t.hora,
        t.estado,
        s.nombre_sede,
        t.tipo_donacion 
    FROM ll_turnos t
    INNER JOIN ll_sede s ON t.id_sede = s.id_sede
    WHERE t.id_registro = ?
    ORDER BY t.fecha DESC
";

$stmt2 = $conexion->prepare($sql_turnos);

$stmt2->bind_param("i", $id_registro);

$stmt2->execute();

$result_turnos = $stmt2->get_result();

?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalle del Donante</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styleadmin.css">
</head>

<body>
    <header class="headeradmin">
        <div class="logo">
            <img src="imagenes/imagenlogolifeline.png" alt="Life Line Logo">
        </div>
        <nav>
            <ul class="nav-links">
                <li><a href="admin.php">Lista de donantes</a></li>
                <li><a href="admin_alerta.php">Alertas</a></li>
            </ul>
        </nav>
    </header>
    <div class="container mt-5">
        <h2>Detalle del Donante</h2>

        <div class="card p-3 mb-4">
            <h4><?php echo htmlspecialchars($donante['nombre'] . " " . $donante['apellido']); ?></h4>
            <p><strong>Tipo de Sangre:</strong> <?php echo htmlspecialchars($donante['tipo_sangre']); ?></p>
            <p><strong>Correo:</strong> <?php echo htmlspecialchars($donante['correo']); ?></p>
            <p><strong>DNI:</strong> <?php echo htmlspecialchars($donante['dni']); ?></p>
        </div>

        <h4>Historial de Donaciones</h4>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Fecha</th>
                    <th>Hora</th>
                    <th>Sede</th>
                    <th>Tipo de Donación</th>
                    <th>Estado</th>
                    <th>disponibilidad</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result_turnos->num_rows > 0): ?>
                    <?php while ($turno = $result_turnos->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($turno['fecha']); ?></td>
                            <td><?php echo htmlspecialchars($turno['hora']); ?></td>
                            <td><?php echo htmlspecialchars($turno['nombre_sede']); ?></td>
                            <td><?php echo htmlspecialchars($turno['tipo_donacion']); ?></td>
                            <td>
                                <select class="form-select estado-select" data-id="<?php echo $turno['id_turno']; ?>">
                                    <option value="Pendiente" <?php if ($turno['estado'] == 'Pendiente') echo 'selected'; ?>>Pendiente</option>
                                    <option value="Completado" <?php if ($turno['estado'] == 'Completado') echo 'selected'; ?>>Completado</option>
                                    <option value="Cancelado" <?php if ($turno['estado'] == 'Cancelado') echo 'selected'; ?>>Cancelado</option>
                                </select>
                            </td>
                            <td>
                                <?php if ($turno['estado'] == 'Completado'): ?>
                                    <button class="btn btn-success btn-sm notificar-btn"
                                        data-correo="<?php echo htmlspecialchars($donante['correo']); ?>"
                                        data-nombre="<?php echo htmlspecialchars($donante['nombre']); ?>">
                                        Notificar disponibilidad
                                    </button>
                                <?php else: ?>
                                    <button class="btn btn-secondary btn-sm" disabled>No disponible</button>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="editar_turno.php?id=<?php echo $turno['id_turno']; ?>" class="btn btn-primary btn-sm">Editar</a>
                                <a href="eliminar_turno.php?id=<?php echo $turno['id_turno']; ?>" class="btn btn-primary btn-sm">Eliminar</a>

                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="text-center">No tiene donaciones registradas.</td>
                    </tr>
                <?php endif; ?>
            </tbody>

        </table>
    </div>
    <script>
        document.querySelectorAll('.estado-select').forEach(select => {
            select.addEventListener('change', function() {
                const id_turno = this.dataset.id;
                const estado = this.value;

                fetch('actualizar_estado.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded'
                        },
                        body: `id_turno=${id_turno}&estado=${estado}`
                    })
                    .then(response => response.text())
                    .then(data => {
                        if (data.trim() === 'ok') {
                            alert('Estado actualizado correctamente.');
                        } else {
                            alert('Error al actualizar el estado: ' + data);
                        }
                    })
                    .catch(err => console.error('Error:', err));
            });
        });

        // Enviar notificación de disponibilidad
        document.querySelectorAll('.notificar-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const correo = this.dataset.correo;
                const nombre = this.dataset.nombre;

                fetch('notificar_disponibilidad.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded'
                        },
                        body: `correo=${correo}&nombre=${nombre}`
                    })
                    .then(response => response.text())
                    .then(data => {
                        if (data.trim() === 'ok') {
                            alert('Correo de disponibilidad enviado correctamente.');
                        } else {
                            alert('Error al enviar correo: ' + data);
                        }
                    })
                    .catch(err => console.error('Error:', err));
            });
        });
    </script>



</body>

</html>